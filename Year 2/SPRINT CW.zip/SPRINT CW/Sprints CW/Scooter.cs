﻿// Derived class for Scooter
public class Scooter : Vehicle
{
    //  Setting up property for scooter
    public int BatteryLife { get; set; }

    // Constructor for scooter classs
    public Scooter(string brand, int year, int batteryLife) : base("Scooter", brand, year)
    {
        this.BatteryLife = batteryLife;
    }

    // How to print Scooter information
    public string PrintScooter()
    {
        return $"{base.Print()}, Battery Life: {BatteryLife}%";
    }
}