﻿// Singleton class for the Booking System
class BookingSystem
{
    private static BookingSystem instance;
    private List<Vehicle> vehicles;

    // Private constructor to enforce singleton pattern
    private BookingSystem()
    {
        vehicles = new List<Vehicle>();
    }

    // Property to get the instance of BookingSystem (Singleton pattern)
    public static BookingSystem Instance
    {
        get
        {
            // If the instance is null, create a new instance
            if (instance == null)
            {
                instance = new BookingSystem();
            }
            return instance;
        }
    }

    // How to add a vehicle to the booking system
    public void AddVehicle(Vehicle vehicle)
    {
        vehicles.Add(vehicle);
    }

    // How to book a vehicle
    public bool BookVehicle(string vehicleBrand, string userName)
    {
        // Find the vehicle in the list
        Vehicle vehicle = vehicles.Find(i => i.Brand == vehicleBrand);

        // Check if the vehicle is found and not booked
        if (vehicle != null && !vehicle.IsBooked)
        {
            vehicle.IsBooked = true;
            Console.WriteLine($"{userName} has successfully booked {vehicleBrand}.");
            return true;
        }

        // Vehicle not found or already booked
        Console.WriteLine($"Sorry, {userName} {vehicleBrand} is not available for booking.");
        return false;
    }

    // How to release a vehicle
    public void ReleaseVehicle(string vehicleBrand)
    {
        // Find the vehicle in the list
        Vehicle vehicle = vehicles.Find(i => i.Brand == vehicleBrand);

        // Check if the vehicle is found and booked
        if (vehicle != null && vehicle.IsBooked)
        {
            vehicle.IsBooked = false;
            Console.WriteLine($"{vehicleBrand} has been released and is now available for booking.");
        }
    }

    // How to display vehicle availability
    public void DisplayVehicleAvailability()
    {
        Console.WriteLine("Vehicle Availability:");
        foreach (var vehicle in vehicles)
        {
            Console.WriteLine($"{vehicle.Print()}");
        }
    }
}
