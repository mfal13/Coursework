﻿using System;

// Main program
class Program
{
    static void Main()
    {
        // Creating objects of different types
        Bike bike = new Bike("GT Bicycles", 2022, 6);
        Scooter scooter = new Scooter("APOLLO", 2019, 78);
        Moped moped = new Moped("Piaggio", 2020, 50);

        // Adding vehicles to the booking system
        BookingSystem bookingSystem = BookingSystem.Instance;
        bookingSystem.AddVehicle(bike);
        bookingSystem.AddVehicle(scooter);
        bookingSystem.AddVehicle(moped);

        // Creating equipment for each vehicle type
        Equipment bikeEquipment = new Equipment(true, false, true);
        Equipment scooterEquipment = new Equipment(true, true, false);
        Equipment mopedEquipment = new Equipment(true, true, true);

        // Creating pre-created users
        User user1 = new User("Maddalena");
        User user2 = new User("Alex");
        User user3 = new User("Joshua");

        // Outputting bike information
        Console.WriteLine("Bike Information:");
        Console.WriteLine(bike.PrintBike());
        Console.WriteLine("Bike Equipment Information:");
        bikeEquipment.PrintEquipment();
        Console.WriteLine();
        Console.WriteLine();

        // Outputting scooter information
        Console.WriteLine("Scooter Information:");
        Console.WriteLine(scooter.PrintScooter());
        Console.WriteLine("Scooter Equipment Information:");
        scooterEquipment.PrintEquipment();
        Console.WriteLine();
        Console.WriteLine();

        // Outputting moped information
        Console.WriteLine("Moped Information:");
        Console.WriteLine(moped.PrintMoped());
        Console.WriteLine("Moped Equipment Information:");
        mopedEquipment.PrintEquipment();
        Console.WriteLine();
        Console.WriteLine();

        // Booking system usage
        Console.WriteLine("Booking System:");

        // User 1 books the bike
        bookingSystem.BookVehicle("GT Bicycles", user1.Name);

        // User 2 tries to book the same bike
        bookingSystem.BookVehicle("GT Bicycles", user2.Name);

        // User 2 tries to book a moped
        bookingSystem.BookVehicle("Piaggio", user2.Name);

        // User 3 tries to book scooter
        bookingSystem.BookVehicle("APOLLO", user3.Name);

        // Displaying vehicle availability
        Console.WriteLine();
        bookingSystem.DisplayVehicleAvailability();
    }
}