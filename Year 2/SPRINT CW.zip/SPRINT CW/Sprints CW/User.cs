﻿// Base class for users
public class User
{
    // Property for user's name
    public string Name { get; }

    // Constructor to make user 's name
    public User(string name)
    {
        Name = name;
    }
}