﻿// Base class for vehicles
public class Vehicle
{
    // Properties for vehicle details
    public string Type { get; set; }
    public string Brand { get; set; }
    public int Year { get; set; }

    // Property to track availability
    public bool IsBooked { get; set; }

    // Constructor to initialize vehicle details
    public Vehicle(string type, string brand, int year)
    {
        this.Type = type;
        this.Brand = brand;
        this.Year = year;
        // Initialize as not booked
        this.IsBooked = false; 
    }

    // How to print vehicle information
    public string Print()
    {
        return ($"Type: {Type}, Brand: {Brand}, Year: {Year}, Availability: {(IsBooked ? "Booked" : "Available")}");
    }
}
