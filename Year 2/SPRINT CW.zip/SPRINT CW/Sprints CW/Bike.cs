﻿// Derived class for Bike
public class Bike : Vehicle
{
    // Setting up property for bike
    public int NumberOfGears { get; set; }

    // Constructor for Bike, invoking the base class constructor
    public Bike(string brand, int year, int numberOfGears) : base("Bike", brand, year)
    {
        this.NumberOfGears = numberOfGears;
    }

    // How to print Bike information
    public string PrintBike()
    {
        return $"{base.Print()}, Number of Gears: {NumberOfGears}";
    }
}