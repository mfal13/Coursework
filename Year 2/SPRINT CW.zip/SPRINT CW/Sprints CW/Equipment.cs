﻿// Composite class for Equipment
public class Equipment
{
    // Properties for equipment details
    public bool Helmet { get; set; }
    public bool KneePads { get; set; }
    public bool Gloves { get; set; }

    // Constructor to make equipment details
    public Equipment(bool helmet, bool kneePads, bool gloves)
    {
        this.Helmet = helmet;
        this.KneePads = kneePads;
        this.Gloves = gloves;
    }
    // How to print equipment information
    public void PrintEquipment()
    {
        Console.WriteLine($"Helmet: {Helmet}, Knee Pads: {KneePads}, Gloves: {Gloves}");
    }
}
