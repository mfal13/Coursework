﻿// Derived class for Moped
public class Moped : Vehicle
{
    //  Setting up property for moped
    public int EngineSize { get; set; }

    // Constructor for Moped, invoking the base class constructor
    public Moped(string brand, int year, int engineSize) : base("Moped", brand, year)
    {
        this.EngineSize = engineSize;
    }

    // How to print Moped information
    public string PrintMoped()
    {
        return $"{base.Print()}, Engine Size: {EngineSize} cc";
    }
}